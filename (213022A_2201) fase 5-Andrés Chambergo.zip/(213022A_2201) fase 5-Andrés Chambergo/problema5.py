# PASO 1: Crear la matriz con 4 recursos y horas diarias
registro_horas = [
    ["Ana", 8, 8, 8, 8, 8],
    ["Luis", 7, 9, 8, 10, 7],
    ["Carla", 6, 6, 7, 7, 6],
    ["Pedro", 9, 9, 8, 8, 9]
]

HORAS_ESTANDAR = 40

# PASO 2: Definir la función/módulo de cálculo y clasificación
def procesar_horas(matriz, umbral):
    resultados = []
    for recurso in matriz:
        nombre = recurso[0]
        horas_diarias = recurso[1:]
        total_semanal = sum(horas_diarias)
        
        if total_semanal > umbral:
            clasificacion = "Sobretiempo"
        else:
            clasificacion = "Horario Estándar o inferior"
        
        resultados.append([nombre, total_semanal, clasificacion])
    return resultados

# PASO 3: Ejecutar el procesamiento
datos_finales = procesar_horas(registro_horas, HORAS_ESTANDAR)

# PASO 4: Imprimir los resultados
print("=== RESUMEN DE HORAS SEMANALES ===")
for dato in datos_finales:
    nombre, total, tipo_jornada = dato
    print(f"Nombre: {nombre} | Total horas: {total} | Clasificación: {tipo_jornada}")